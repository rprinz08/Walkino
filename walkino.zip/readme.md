# Walkino
Programming your Walkera R/C receiver with the
Arduino IDE.


## Objectives
Basic idea for this project was to develop
alternate firmwares for some Walkera R/C receivers. After analyzing two popular receivers,
one the RX2634H from the [QR-Ladybird](https://www.google.com/search?q=qr-ladybird&tbm=isch) and the
other the RX2635H from the [Hoten-X](https://www.google.com/search?q=hoten-x&tbm=isch) both based
on the Atmel [XMEGA32A4](http://www.atmel.com/devices/ATXMEGA32A4.aspx) it looked feasible that
this could be done.

And whats the easiest way today to develop
software for microcontroller? Right, it's the
Arduino IDE. So this project provides all
thats needed to integrate these board into the
Arduino IDE.

Successful test where performed with IDEs version 1.6.5 up to
the current version (as of this writing) 1.6.12.
Linux and Windows are equally supported, MAC OS was not
tested.

Additional information about the hardware of
both receivers as well as for this project
could be found in a series of blog posts
about [Walkino](https://www.min.at/prinz/?x=cat:510).

Even if you are not into R/C quadcopters this
project could be interesting. The boards are
relatively cheap available on platforms like
amazon or ebay and provide a great platform
for Atmel XMEGA based development and contain
a lot of interesting sensors.


## Installation
First install [Arduino IDE](https://www.arduino.cc/en/Main/Software).
Next you have two options to install this project.

1. Download the distribution ZIP file end extract it
   into the root directory of the Arduino IDE (the folder
   which contains the file **arduino** which starts the
   IDE).

2. The other way is to clone the GIT repository
   right into this folder. This has the advantage
   that updates could be easily done using **git update**.

Both methods do not overwrite or change any files of
the standard IDE installation and can be completely
removed using the provided **uninstall.sh** (for Linux or
**uninstall.cmd** for Windows) script.

Included in this project are compiled binaries of
the [UP42](https://github.com/rprinz08/UP42) utility
which is needed to transfer compiled sketches to
the receiver. You could also compile it yourself
from source for security reasons if you want.
Versions for Windows and Linux are provided as 32bit and 64bit
binaries. If you are on a 32bit system you have to
manually rename the 32bit versions **up42-32** to
**up42** as the default is 64bit. These utilities
could be found in the **hardware/tools/walkera/linux**
or **hardware/tools/walkera/windows** folders inside the
Arduino IDE folder.

To connect the receiver boards to the development PC
either an original Walkera UP02 or a USB to serial
converter is needed. More infos about that topic are
available [here](https://www.min.at/prinz/?x=entry:entry150622-125650)
and [here](https://www.min.at/prinz/?x=entry:entry161004-215304).


## Usage
![Arduino IDE](misc/walkino.png)
Select one of the two new boards which are available After
installation under the **Tools/Board** menu. Then select
the serial port where the board is connected.

To start you can select one of the available examples
under **File/Examples/Walkino**


## Contributing / Developing
Walkino is not 100% complete or bug free. If you found
any bug or have an idea for improvements - great! Feel
free to contribute.

1. Fork it on github!
2. Create your feature branch: `git checkout -b my-new-feature`
3. Commit your changes: `git commit -am 'Add some feature'`
4. Push to the branch: `git push origin my-new-feature`
5. Submit a pull request :-)

To start development no dependencies except the Arduino
IDE are needed. I personally develop using [Visual Studio
Code](https://code.visualstudio.com) as an editor and this project includes a workspace
settings folder for it. If you prefer another editor just
ignore this folder.

1. Open root folder of Arduino IDE with vscode and start coding
2. Press CTRL+SHIFT+B in vscode builds project dist ZIP
   file.


## Notes
* lost-node is developed with:
  * node.js version 4.2.2 (64bit)
  * mongodb version 3.0.7
  * Visual Studio Code version 0.10.3

* JayData odata-server / jaydata 1.3.6 node module does not work with
mongodb client >= 2.0
(see https://www.mongodb.com/blog/post/introducing-nodejs-mongodb-20-driver)
So use the latest 1 version (1.4.39) instead. This is also defined in
package.json

* You can use
  * LINQPad https://www.linqpad.net/
  * Sesame Data Browser http://metasapiens.com/sesame/data-browser/preview/

  to access the LoST database using odata via
  * http://localhost:8080/lost.data.svc

* Also note that this version is not complete und highly untested.
Feel free to contribute to make lost-node better. Especially missing
in this version are forward and redirect functionalities and a
management frontend.

* For windows, binaries for mongodb, the VUE admin tool and
  the libxmljs node modules are included. So you dont need
  mongodb or Visual Studio installed on windows. The precompiled windows
  module binaries are 64bit versions! If you use a 32bit node you have to
  compile 32bit modules yourself. To use it
  follow this instructions:

  1. before running `npm install` copy the `package.json` file
     to a safe place. Next remove the following lines
     in the dependencies section from `package.json`:
     * libxml-to-js
     * libxmljs
     * mongodb
     * odata-server
  2. run `npm install`
  3. inside the `build` folder you will find `windows_prebuilt_modules.zip`.
      Extract its contents into the `node_modules` folder.
  4. Restore the `package.json` backup from point 1.
  5. Run `npm install` again to install the remaining dependencies.
  6. Now you should have all dependencies installed.

* The LoST testing application supports multiple map providers. For Google and
Microsoft BING Maps you will need an API key. See the notes in the corresponding
soures files:
  * source/client/test.html - Google Maps
  * source/client/assets/js/nl.map.js - BING Maps

## History
* Alpha Version 17.2.2016
* First Public Beta 7.10.2016


## Credits
Credits go to all used components libraries.


## License
This project is under GNU GPLv3.
See file gpl-3.0-walkino.txt in this project or
http://www.gnu.org/licenses/gpl-3.0.html

